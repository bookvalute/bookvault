# BookVault — Android-only deployment

This package is prepared for cloud deployment. You do not need to run Node.js on your Android phone.

## 1. GitHub
- Create a new GitHub repository.
- Upload all files/folders from this package to the repository root.
- Do NOT upload `.env`, database files, or `storage/` files.

## 2. Railway
- Open Railway and create a new project from the GitHub repository.
- Railway will run `npm install` and `npm start`.
- `npm start` automatically runs the setup script and then starts the server.

## 3. Railway Volume (IMPORTANT)
Create a persistent Volume and mount it at:
`/data`

Then set these variables:
- `DATABASE_PATH=/data/database/bookvault.db`
- `STORAGE_PATH=/data/storage`
- `PDF_PRIVATE_PATH=/data/storage/books/private`
- `COVERS_PATH=/data/storage/covers`
- `SCREENSHOTS_PATH=/data/storage/screenshots`

Without a persistent volume, uploaded PDFs and SQLite data can be lost when the service is recreated.

## 4. Environment variables
Copy the variables from `.env.example` into Railway Variables and replace every placeholder.

Set `FRONTEND_URL` to the public Railway URL after the first deployment.

## 5. Admin
Set `ADMIN_EMAIL` and `ADMIN_PASSWORD`. On first boot, BookVault automatically creates the admin account if it does not already exist.

## 6. Email
For Gmail, enable 2-Step Verification and create a Gmail App Password. Put the 16-character App Password in `EMAIL_PASSWORD`.

## 7. Test
Open:
- `/` customer store
- `/admin` admin panel

Test: add book → place test order → verify order → deliver PDF → download link.
