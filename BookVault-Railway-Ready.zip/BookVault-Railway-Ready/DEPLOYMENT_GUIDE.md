# BookVault — Complete Deployment Guide

## What You've Built
A real full-stack digital book store with:
- Premium 3D Three.js rotating book carousel
- Secure PDF storage & delivery
- JazzCash / EasyPaisa payment flow
- Admin panel with order management
- Email notifications
- Secure expiring download links

---

## STEP 1 — Install Node.js

Download from: https://nodejs.org (version 18 or higher)

Verify: `node --version`

---

## STEP 2 — Project Setup

```bash
# Go to backend folder
cd bookvault/backend

# Install all packages
npm install

# Copy environment file
cp .env.example .env
```

---

## STEP 3 — Configure .env File

Open `.env` in any text editor and fill in:

### Required Settings:

```env
PORT=5000
NODE_ENV=production
FRONTEND_URL=http://localhost:5000

# Change these to random long strings (min 32 chars)
JWT_SECRET=put_any_very_long_random_string_here_min32
SESSION_SECRET=another_long_random_string_here_min32
DOWNLOAD_SECRET=yet_another_random_string_here_min32

# Your admin login
ADMIN_EMAIL=your@email.com
ADMIN_PASSWORD=YourStrongPassword123!

# Database (leave as is — SQLite, no setup needed)
DATABASE_PATH=./database/bookvault.db
```

---

## STEP 4 — Configure Email (Gmail)

1. Go to: https://myaccount.google.com/security
2. Enable "2-Step Verification"
3. Search "App passwords"
4. Create app password → select "Mail"
5. Copy the 16-character password

```env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=youremail@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop   ← paste app password here
EMAIL_FROM_NAME=BookVault
EMAIL_FROM=youremail@gmail.com
ADMIN_EMAIL_NOTIFY=youremail@gmail.com
```

---

## STEP 5 — Payment Settings

```env
JAZZCASH_NUMBER=0300-0000000   ← your JazzCash number
EASYPAISA_NUMBER=0300-0000000  ← your EasyPaisa number
ACCOUNT_NAME=Your Full Name
```

You can also change these anytime from the Admin Panel → Settings.

---

## STEP 6 — Create Admin Account

```bash
npm run setup
```

This creates your first admin account using the email/password in .env.

---

## STEP 7 — Run the Server

```bash
# Development
npm run dev

# Production
npm start
```

Server runs on: http://localhost:5000
Admin Panel: http://localhost:5000/admin

---

## STEP 8 — First Login

1. Go to: http://localhost:5000/admin
2. Enter your ADMIN_EMAIL and ADMIN_PASSWORD
3. You're in!

---

## STEP 9 — Add Your First Book

1. Admin Panel → Books → + Add New Book
2. Fill in: Title, Author, Price (PKR)
3. Upload cover image (JPG/PNG)
4. Upload PDF file
5. Check "Published" and "Show in 3D Carousel"
6. Save

Your book appears instantly on the store.

---

## STEP 10 — Test the Full Flow

1. Go to: http://localhost:5000
2. Browse books in 3D carousel
3. Click "Buy Now"
4. Fill in customer details
5. Select JazzCash
6. Your number shows up
7. Enter any transaction ID
8. Upload any screenshot
9. Place order

Admin Panel:
- Orders → See new order
- Click View → See payment screenshot
- Click "Verify Payment"
- Click "Send PDF to Customer"
- Customer receives email with secure download link

---

## PRODUCTION DEPLOYMENT

### Option A: VPS (DigitalOcean / Vultr / Linode)

1. Get a VPS with Ubuntu 22.04 ($6/month)
2. Install Node.js: `curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install -y nodejs`
3. Upload project via FTP/SFTP
4. Install PM2: `npm install -g pm2`
5. Start: `pm2 start src/server.js --name bookvault`
6. Auto-start: `pm2 startup && pm2 save`
7. Point your domain with Nginx

### Option B: Railway.app (Easiest — Free tier available)

1. Go to: https://railway.app
2. Connect GitHub
3. Upload project to GitHub
4. New Project → Deploy from GitHub
5. Add environment variables in Railway dashboard
6. Deploy automatically

### Option C: Render.com (Free tier)

1. Go to: https://render.com
2. New Web Service → Connect repo
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables
6. Deploy

---

## DOMAIN SETUP

1. Buy domain at: Namecheap, GoDaddy, or Hostinger
2. Point DNS to your server IP
3. Install SSL certificate:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

Change in .env:
```env
FRONTEND_URL=https://yourdomain.com
NODE_ENV=production
```

---

## FILE STORAGE

All private files are stored locally:
- PDFs: `backend/storage/books/private/` ← Never public
- Screenshots: `backend/storage/screenshots/` ← Never public
- Covers: `backend/storage/covers/` ← Public

For production, back up the `storage/` and `database/` folders regularly.

---

## SECURITY CHECKLIST

- [ ] Changed JWT_SECRET to random string
- [ ] Changed ADMIN_PASSWORD to strong password
- [ ] .env file is NOT committed to git
- [ ] HTTPS is enabled on production
- [ ] PDF folder is not publicly accessible
- [ ] Admin panel requires login

---

## ADMIN PANEL FEATURES

| Feature | Location |
|---------|----------|
| Add/Edit/Delete books | Admin → Books |
| Upload book cover | Admin → Books → 🖼 Cover |
| Upload PDF | Admin → Books → 📄 PDF |
| View orders | Admin → Orders |
| Verify payment | Admin → Orders → View → ✅ Verify |
| Send PDF to customer | Admin → Orders → 📧 Send PDF |
| View payment screenshot | Admin → Orders → View |
| Change JazzCash number | Admin → Settings |
| View customers | Admin → Customers |
| Sales analytics | Admin → Dashboard |

---

## CUSTOMER FLOW

1. Visit store
2. Browse 3D rotating books
3. Click book → details appear
4. Click "Buy Now"
5. Enter name, email, phone
6. Select JazzCash or EasyPaisa
7. Your number + amount shown
8. Customer sends payment
9. Customer enters transaction ID
10. Customer uploads screenshot
11. Order placed → email sent
12. Admin verifies payment
13. Admin clicks "Send PDF"
14. Customer receives secure email link
15. Customer downloads PDF (link expires in 72 hours)

---

## TROUBLESHOOTING

**"Server error" on login:**
→ Make sure backend is running: `npm start`

**Books not loading:**
→ Check browser console. Backend may not be running.

**Emails not sending:**
→ Check Gmail App Password. Make sure 2FA is enabled.

**PDF not uploading:**
→ Check storage folder permissions: `chmod 755 backend/storage`

**Admin can't login:**
→ Run `npm run setup` again

---

## Support

BookVault is fully functional. Every button works:
- Add to Cart ✅
- Buy Now ✅
- Payment flow ✅
- Admin order management ✅
- PDF delivery via email ✅
- Secure download links ✅
- Order lookup ✅
