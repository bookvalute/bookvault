const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DATABASE_PATH || './database/bookvault.db';
const dbDir = path.dirname(path.resolve(DB_PATH));
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.resolve(DB_PATH));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function initDatabase() {
  db.exec(`
    -- Admins table
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL DEFAULT 'Admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    );

    -- Categories table
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Books table
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      subtitle TEXT,
      description TEXT,
      category_id INTEGER REFERENCES categories(id),
      price INTEGER NOT NULL DEFAULT 0,
      original_price INTEGER,
      discount_percent INTEGER DEFAULT 0,
      cover_filename TEXT,
      pdf_filename TEXT,
      language TEXT DEFAULT 'Urdu',
      pages INTEGER,
      isbn TEXT,
      format TEXT DEFAULT 'PDF',
      is_featured INTEGER DEFAULT 0,
      in_carousel INTEGER DEFAULT 0,
      is_published INTEGER DEFAULT 0,
      spine_color TEXT DEFAULT '#c9913a',
      emoji_icon TEXT DEFAULT '📘',
      sales_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Customers table
    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      order_count INTEGER DEFAULT 0,
      total_spent INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Orders table
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT UNIQUE NOT NULL,
      customer_id INTEGER REFERENCES customers(id),
      customer_name TEXT NOT NULL,
      customer_email TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      amount INTEGER NOT NULL,
      payment_method TEXT NOT NULL CHECK(payment_method IN ('jazzcash','easypaisa')),
      transaction_id TEXT,
      screenshot_filename TEXT,
      order_status TEXT DEFAULT 'pending' CHECK(order_status IN ('pending','payment_submitted','payment_verified','payment_rejected','processing','delivered','cancelled','refunded')),
      payment_status TEXT DEFAULT 'pending' CHECK(payment_status IN ('pending','submitted','verified','rejected','refunded')),
      delivery_status TEXT DEFAULT 'pending' CHECK(delivery_status IN ('pending','processing','delivered','failed')),
      admin_note TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      verified_at DATETIME,
      delivered_at DATETIME
    );

    -- Order items table
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL REFERENCES orders(id),
      book_id INTEGER NOT NULL REFERENCES books(id),
      book_title TEXT NOT NULL,
      book_author TEXT NOT NULL,
      price INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Secure downloads table
    CREATE TABLE IF NOT EXISTS downloads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token TEXT UNIQUE NOT NULL,
      order_id INTEGER NOT NULL REFERENCES orders(id),
      order_item_id INTEGER NOT NULL REFERENCES order_items(id),
      book_id INTEGER NOT NULL REFERENCES books(id),
      customer_email TEXT NOT NULL,
      download_count INTEGER DEFAULT 0,
      max_downloads INTEGER DEFAULT 5,
      expires_at DATETIME NOT NULL,
      last_downloaded_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      is_active INTEGER DEFAULT 1
    );

    -- Notifications table
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      data TEXT,
      is_read INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Settings table
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Default categories
    INSERT OR IGNORE INTO categories (name, slug) VALUES
      ('Business Strategy', 'business-strategy'),
      ('Marketing', 'marketing'),
      ('Finance', 'finance'),
      ('Leadership', 'leadership'),
      ('Sales', 'sales'),
      ('Entrepreneurship', 'entrepreneurship'),
      ('Self Help', 'self-help'),
      ('Technology', 'technology'),
      ('Personal Development', 'personal-development'),
      ('Islamic Books', 'islamic-books');

    -- Default settings
    INSERT OR IGNORE INTO settings (key, value) VALUES
      ('site_name', 'BookVault'),
      ('site_tagline', 'Discover. Read. Inspire.'),
      ('footer_text', '© 2024 BookVault. All rights reserved.'),
      ('contact_email', 'contact@bookvault.pk'),
      ('whatsapp_number', '+923000000000'),
      ('jazzcash_number', '0300-0000000'),
      ('easypaisa_number', '0300-0000000'),
      ('account_name', 'Your Name'),
      ('currency', 'PKR'),
      ('free_delivery_threshold', '2000'),
      ('carousel_visible', 'true'),
      ('accent_color', '#c9913a'),
      ('download_expiry_hours', '72'),
      ('max_downloads', '5');
  `);

  console.log('✅ Database initialized');
}

module.exports = { db, initDatabase };
