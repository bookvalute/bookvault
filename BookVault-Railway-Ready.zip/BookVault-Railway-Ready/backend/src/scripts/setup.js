require('dotenv').config();
const bcrypt = require('bcryptjs');
const { db, initDatabase } = require('../config/database');

console.log('\n🚀 BookVault Setup Script\n');

initDatabase();

const email = process.env.ADMIN_EMAIL || 'admin@bookvault.pk';
const password = process.env.ADMIN_PASSWORD || 'Admin@BookVault123!';
const name = 'Admin';

const existing = db.prepare('SELECT id FROM admins WHERE email = ?').get(email);
if (existing) {
  console.log(`✅ Admin already exists: ${email}`);
} else {
  const hash = bcrypt.hashSync(password, 12);
  db.prepare('INSERT INTO admins (email, password_hash, name) VALUES (?, ?, ?)').run(email, hash, name);
  console.log(`✅ Admin created:`);
  console.log(`   Email: ${email}`);
  console.log(`   Password: ${password}`);
  console.log(`\n⚠️  IMPORTANT: Change your password after first login!`);
}

console.log('\n✅ Setup complete! Run: npm start\n');
process.exit(0);
