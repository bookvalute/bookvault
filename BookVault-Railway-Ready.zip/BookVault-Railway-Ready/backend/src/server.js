require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const { initDatabase } = require('./config/database');
const { COVERS_PATH } = require('./middleware/upload');

const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 5000;

// Init DB first
initDatabase();

// ── Security middleware ──
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET','POST','PUT','DELETE','OPTIONS']
}));
app.use(cookieParser());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Rate limiting ──
const apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', apiLimiter);

// ── Public file serving (covers only — PDFs are NEVER public) ──
const coversPath = path.resolve(COVERS_PATH);
app.use('/api/public/covers', express.static(coversPath, {
  setHeaders: (res) => { res.setHeader('Cache-Control', 'public, max-age=86400'); }
}));

// ── Public API routes ──
app.use('/api/books', require('./routes/books'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/download', require('./routes/download'));
app.use('/api/public', require('./routes/public'));

// Quick pay-info endpoint (non-sensitive)
app.get('/api/orders/pay-info', (req, res) => {
  const { db } = require('./config/database');
  const get = (k) => db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value || '';
  res.json({ jazz: get('jazzcash_number'), easy: get('easypaisa_number'), name: get('account_name') });
});

// ── Admin routes (all protected) ──
app.use('/api/admin/auth', require('./routes/admin.auth'));
app.use('/api/admin/books', require('./routes/admin.books'));
app.use('/api/admin/orders', require('./routes/admin.orders'));
app.use('/api/admin/dashboard', require('./routes/admin.dashboard'));
app.use('/api/admin/customers', require('./routes/admin.dashboard'));
app.use('/api/admin/settings', require('./routes/admin.dashboard'));
app.use('/api/admin/notifications', require('./routes/admin.dashboard'));

// ── Serve frontend ──
const frontendPath = path.join(__dirname, '../../frontend');
if (fs.existsSync(frontendPath)) {
  app.use(express.static(frontendPath));
  // Admin panel — only serve to authenticated requests (JS handles the auth check)
  app.get('/admin*', (req, res) => res.sendFile(path.join(frontendPath, 'admin.html')));
  app.get('*', (req, res) => res.sendFile(path.join(frontendPath, 'index.html')));
}

// ── Error handler ──
app.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'File too large' });
  if (err.message?.includes('Only') || err.message?.includes('allowed')) {
    return res.status(400).json({ error: err.message });
  }
  console.error('Server error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`\n🚀 BookVault Server running on port ${PORT}`);
  console.log(`📚 Frontend: ${process.env.FRONTEND_URL || 'http://localhost:3000'}`);
  console.log(`🔑 Admin panel: ${process.env.FRONTEND_URL || 'http://localhost:3000'}/admin`);
  console.log(`✅ Environment: ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app;
