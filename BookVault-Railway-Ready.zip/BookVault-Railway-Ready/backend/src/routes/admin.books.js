const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { db } = require('../config/database');
const { adminAuth } = require('../middleware/auth');
const { uploadCover, uploadPDF, COVERS_PATH, PDF_PATH } = require('../middleware/upload');

// GET /api/admin/books
router.get('/', adminAuth, (req, res) => {
  const books = db.prepare(`SELECT b.*, c.name as category_name FROM books b
    LEFT JOIN categories c ON b.category_id=c.id ORDER BY b.created_at DESC`).all();
  res.json({ books });
});

// POST /api/admin/books
router.post('/', adminAuth, (req, res) => {
  const { title, author, subtitle, description, category_id, price, original_price,
    language, pages, isbn, format, is_featured, in_carousel, is_published,
    spine_color, emoji_icon } = req.body;

  if (!title?.trim()) return res.status(400).json({ error: 'Title required' });
  if (!author?.trim()) return res.status(400).json({ error: 'Author required' });
  if (!price || isNaN(price)) return res.status(400).json({ error: 'Valid price required' });

  const actualPrice = Math.abs(parseInt(price));
  const actualOrigPrice = original_price ? Math.abs(parseInt(original_price)) : null;
  const discount = actualOrigPrice && actualOrigPrice > actualPrice
    ? Math.round((1 - actualPrice / actualOrigPrice) * 100) : 0;

  const result = db.prepare(`INSERT INTO books
    (title, author, subtitle, description, category_id, price, original_price, discount_percent,
     language, pages, isbn, format, is_featured, in_carousel, is_published, spine_color, emoji_icon)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
    title.trim(), author.trim(), subtitle?.trim() || null, description?.trim() || null,
    category_id || null, actualPrice, actualOrigPrice, discount,
    language || 'Urdu', pages ? parseInt(pages) : null, isbn?.trim() || null,
    format || 'PDF', is_featured === '1' ? 1 : 0, in_carousel === '1' ? 1 : 0,
    is_published === '1' ? 1 : 0, spine_color || '#c9913a', emoji_icon || '📘'
  );

  res.json({ success: true, book_id: result.lastInsertRowid });
});

// PUT /api/admin/books/:id
router.put('/:id', adminAuth, (req, res) => {
  const book = db.prepare('SELECT * FROM books WHERE id = ?').get(req.params.id);
  if (!book) return res.status(404).json({ error: 'Book not found' });

  const { title, author, subtitle, description, category_id, price, original_price,
    language, pages, isbn, format, is_featured, in_carousel, is_published,
    spine_color, emoji_icon } = req.body;

  const actualPrice = price ? Math.abs(parseInt(price)) : book.price;
  const actualOrigPrice = original_price ? Math.abs(parseInt(original_price)) : book.original_price;
  const discount = actualOrigPrice && actualOrigPrice > actualPrice
    ? Math.round((1 - actualPrice / actualOrigPrice) * 100) : 0;

  db.prepare(`UPDATE books SET title=?, author=?, subtitle=?, description=?, category_id=?,
    price=?, original_price=?, discount_percent=?, language=?, pages=?, isbn=?, format=?,
    is_featured=?, in_carousel=?, is_published=?, spine_color=?, emoji_icon=?,
    updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(
    title?.trim() || book.title, author?.trim() || book.author,
    subtitle?.trim() ?? book.subtitle, description?.trim() ?? book.description,
    category_id || book.category_id, actualPrice, actualOrigPrice, discount,
    language || book.language, pages ? parseInt(pages) : book.pages,
    isbn?.trim() || book.isbn, format || book.format,
    is_featured === '1' ? 1 : (is_featured === '0' ? 0 : book.is_featured),
    in_carousel === '1' ? 1 : (in_carousel === '0' ? 0 : book.in_carousel),
    is_published === '1' ? 1 : (is_published === '0' ? 0 : book.is_published),
    spine_color || book.spine_color, emoji_icon || book.emoji_icon, req.params.id
  );

  res.json({ success: true });
});

// DELETE /api/admin/books/:id
router.delete('/:id', adminAuth, (req, res) => {
  const book = db.prepare('SELECT * FROM books WHERE id = ?').get(req.params.id);
  if (!book) return res.status(404).json({ error: 'Book not found' });

  const hasOrders = db.prepare('SELECT COUNT(*) as c FROM order_items WHERE book_id=?').get(req.params.id);
  if (hasOrders.c > 0) return res.status(400).json({ error: 'Cannot delete book with existing orders. Unpublish instead.' });

  // Delete files
  if (book.cover_filename) { try { fs.unlinkSync(path.join(path.resolve(COVERS_PATH), book.cover_filename)); } catch {} }
  if (book.pdf_filename) { try { fs.unlinkSync(path.join(path.resolve(PDF_PATH), book.pdf_filename)); } catch {} }

  db.prepare('DELETE FROM books WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// POST /api/admin/books/:id/cover — upload cover image
router.post('/:id/cover', adminAuth, uploadCover.single('cover'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const book = db.prepare('SELECT cover_filename FROM books WHERE id=?').get(req.params.id);
  if (!book) return res.status(404).json({ error: 'Book not found' });

  // Delete old cover
  if (book.cover_filename) {
    try { fs.unlinkSync(path.join(path.resolve(COVERS_PATH), book.cover_filename)); } catch {}
  }

  db.prepare('UPDATE books SET cover_filename=?, updated_at=CURRENT_TIMESTAMP WHERE id=?')
    .run(req.file.filename, req.params.id);

  res.json({ success: true, cover_url: `/api/public/covers/${req.file.filename}` });
});

// POST /api/admin/books/:id/pdf — upload PDF
router.post('/:id/pdf', adminAuth, uploadPDF.single('pdf'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const book = db.prepare('SELECT pdf_filename FROM books WHERE id=?').get(req.params.id);
  if (!book) return res.status(404).json({ error: 'Book not found' });

  // Delete old PDF
  if (book.pdf_filename) {
    try { fs.unlinkSync(path.join(path.resolve(PDF_PATH), book.pdf_filename)); } catch {}
  }

  db.prepare('UPDATE books SET pdf_filename=?, updated_at=CURRENT_TIMESTAMP WHERE id=?')
    .run(req.file.filename, req.params.id);

  res.json({ success: true, message: 'PDF uploaded securely' });
});

module.exports = router;
