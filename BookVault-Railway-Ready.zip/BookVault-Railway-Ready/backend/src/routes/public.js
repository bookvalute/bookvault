const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// GET /api/public/settings — non-sensitive settings for frontend
router.get('/settings', (req, res) => {
  const keys = ['site_name','site_tagline','footer_text','jazzcash_number',
    'easypaisa_number','account_name','accent_color','carousel_visible',
    'free_delivery_threshold','whatsapp_number','contact_email'];
  const rows = db.prepare(`SELECT key, value FROM settings WHERE key IN (${keys.map(()=>'?').join(',')})`).all(...keys);
  const settings = Object.fromEntries(rows.map(r=>[r.key,r.value]));
  res.json({ settings });
});

module.exports = router;
