const express = require('express');
const router = express.Router();
const path = require('path');
const { db } = require('../config/database');
const { uploadScreenshot } = require('../middleware/upload');
const { generateOrderNumber } = require('../utils/helpers');
const { sendOrderConfirmation, sendAdminNotification } = require('../utils/email');

// POST /api/orders — place an order
router.post('/', uploadScreenshot.single('screenshot'), async (req, res) => {
  const { customer_name, customer_email, customer_phone, payment_method, transaction_id, book_ids } = req.body;

  // Validate
  if (!customer_name?.trim()) return res.status(400).json({ error: 'Name required' });
  if (!customer_email?.trim() || !customer_email.includes('@')) return res.status(400).json({ error: 'Valid email required' });
  if (!customer_phone?.trim()) return res.status(400).json({ error: 'Phone required' });
  if (!payment_method || !['jazzcash', 'easypaisa'].includes(payment_method))
    return res.status(400).json({ error: 'Valid payment method required' });
  if (!transaction_id?.trim()) return res.status(400).json({ error: 'Transaction ID required' });
  if (!req.file) return res.status(400).json({ error: 'Payment screenshot required' });

  let bookIdList;
  try { bookIdList = JSON.parse(book_ids); } catch { bookIdList = [book_ids]; }
  if (!bookIdList?.length) return res.status(400).json({ error: 'No books selected' });

  // Fetch books from DB — NEVER trust frontend price
  const books = bookIdList.map(id => {
    const b = db.prepare('SELECT * FROM books WHERE id = ? AND is_published = 1').get(id);
    if (!b) throw new Error(`Book ${id} not found`);
    return b;
  });

  const totalAmount = books.reduce((sum, b) => sum + b.price, 0);
  const orderNumber = generateOrderNumber();
  const screenshotFilename = req.file.filename;

  try {
    const insertOrder = db.transaction(() => {
      // Upsert customer
      let customer = db.prepare('SELECT id FROM customers WHERE email = ?').get(customer_email.toLowerCase());
      if (!customer) {
        const r = db.prepare('INSERT INTO customers (name, email, phone) VALUES (?, ?, ?)').run(
          customer_name, customer_email.toLowerCase(), customer_phone
        );
        customer = { id: r.lastInsertRowid };
      }

      const orderResult = db.prepare(`
        INSERT INTO orders (order_number, customer_id, customer_name, customer_email, customer_phone,
          amount, payment_method, transaction_id, screenshot_filename, order_status, payment_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'payment_submitted', 'submitted')
      `).run(orderNumber, customer.id, customer_name, customer_email.toLowerCase(),
        customer_phone, totalAmount, payment_method, transaction_id.trim(), screenshotFilename);

      const orderId = orderResult.lastInsertRowid;

      books.forEach(book => {
        db.prepare(`INSERT INTO order_items (order_id, book_id, book_title, book_author, price)
          VALUES (?, ?, ?, ?, ?)`).run(orderId, book.id, book.title, book.author, book.price);
      });

      // Notification
      db.prepare(`INSERT INTO notifications (type, title, message, data) VALUES (?, ?, ?, ?)`).run(
        'new_order',
        `New Order: ${orderNumber}`,
        `${customer_name} ordered ${books.map(b => b.title).join(', ')} for PKR ${totalAmount.toLocaleString()}`,
        JSON.stringify({ order_id: orderId, order_number: orderNumber })
      );

      return orderId;
    });

    const orderId = insertOrder();
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    // Send emails (non-blocking)
    Promise.all([
      sendOrderConfirmation(order, books[0]).catch(e => console.error('Order confirm email failed:', e)),
      sendAdminNotification(order, books[0]).catch(e => console.error('Admin notification email failed:', e))
    ]);

    res.json({
      success: true,
      order_number: orderNumber,
      order_id: orderId,
      amount: totalAmount,
      message: 'Order placed successfully! You will receive an email confirmation shortly.'
    });

  } catch (err) {
    console.error('Order creation error:', err);
    res.status(500).json({ error: 'Failed to create order. Please try again.' });
  }
});

// GET /api/orders/lookup — customer order lookup
router.get('/lookup', (req, res) => {
  const { order_number, email } = req.query;
  if (!order_number || !email) return res.status(400).json({ error: 'Order number and email required' });

  const order = db.prepare(`SELECT o.*, GROUP_CONCAT(oi.book_title, ', ') as books_titles
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.id
    WHERE o.order_number = ? AND o.customer_email = ?
    GROUP BY o.id`).get(order_number.trim().toUpperCase(), email.toLowerCase().trim());

  if (!order) return res.status(404).json({ error: 'Order not found. Check your order number and email.' });

  const downloads = db.prepare(`SELECT d.token, d.expires_at, d.download_count, d.max_downloads,
    d.is_active, oi.book_title, oi.book_id
    FROM downloads d
    JOIN order_items oi ON oi.id = d.order_item_id
    WHERE d.order_id = ? AND d.is_active = 1`).all(order.id);

  res.json({
    order: {
      order_number: order.order_number,
      order_status: order.order_status,
      payment_status: order.payment_status,
      delivery_status: order.delivery_status,
      amount: order.amount,
      payment_method: order.payment_method,
      books: order.books_titles,
      created_at: order.created_at,
      delivered_at: order.delivered_at
    },
    downloads: downloads.map(d => ({
      book_title: d.book_title,
      token: d.token,
      expires_at: d.expires_at,
      download_count: d.download_count,
      max_downloads: d.max_downloads,
      is_expired: new Date(d.expires_at) < new Date(),
      is_available: d.is_active && new Date(d.expires_at) >= new Date() && d.download_count < d.max_downloads
    }))
  });
});

module.exports = router;
