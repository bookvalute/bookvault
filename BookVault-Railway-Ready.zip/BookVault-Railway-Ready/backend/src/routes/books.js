const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// GET /api/books — all published books
router.get('/', (req, res) => {
  const { category, search, featured, carousel, sort } = req.query;
  let query = `SELECT b.*, c.name as category_name FROM books b
    LEFT JOIN categories c ON b.category_id = c.id
    WHERE b.is_published = 1`;
  const params = [];

  if (category) { query += ' AND c.slug = ?'; params.push(category); }
  if (featured === '1') { query += ' AND b.is_featured = 1'; }
  if (carousel === '1') { query += ' AND b.in_carousel = 1'; }
  if (search) {
    query += ' AND (b.title LIKE ? OR b.author LIKE ? OR b.description LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s, s);
  }

  if (sort === 'price-lo') query += ' ORDER BY b.price ASC';
  else if (sort === 'price-hi') query += ' ORDER BY b.price DESC';
  else if (sort === 'az') query += ' ORDER BY b.title ASC';
  else query += ' ORDER BY b.created_at DESC';

  const books = db.prepare(query).all(...params);
  res.json({ books: books.map(sanitizeBook) });
});

// GET /api/books/:id
router.get('/:id', (req, res) => {
  const book = db.prepare(`SELECT b.*, c.name as category_name FROM books b
    LEFT JOIN categories c ON b.category_id = c.id
    WHERE b.id = ? AND b.is_published = 1`).get(req.params.id);
  if (!book) return res.status(404).json({ error: 'Book not found' });
  res.json({ book: sanitizeBook(book) });
});

// GET /api/categories
router.get('/meta/categories', (req, res) => {
  const categories = db.prepare('SELECT * FROM categories ORDER BY name').all();
  res.json({ categories });
});

function sanitizeBook(b) {
  return {
    id: b.id,
    title: b.title,
    author: b.author,
    subtitle: b.subtitle,
    description: b.description,
    category_id: b.category_id,
    category_name: b.category_name,
    price: b.price,
    original_price: b.original_price,
    discount_percent: b.discount_percent,
    cover_url: b.cover_filename ? `/api/public/covers/${b.cover_filename}` : null,
    language: b.language,
    pages: b.pages,
    isbn: b.isbn,
    format: b.format,
    is_featured: b.is_featured,
    in_carousel: b.in_carousel,
    spine_color: b.spine_color,
    emoji_icon: b.emoji_icon,
    sales_count: b.sales_count,
    created_at: b.created_at
  };
}

module.exports = router;
