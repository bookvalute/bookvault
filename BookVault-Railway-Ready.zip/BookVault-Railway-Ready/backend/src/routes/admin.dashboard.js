const express = require('express');
const router = express.Router();
const { db } = require('../config/database');
const { adminAuth } = require('../middleware/auth');
const { getSettings, setSetting } = require('../utils/helpers');

// GET /api/admin/dashboard
router.get('/', adminAuth, (req, res) => {
  const today = new Date().toISOString().slice(0, 10);

  const stats = {
    total_orders: db.prepare("SELECT COUNT(*) as c FROM orders").get().c,
    today_orders: db.prepare("SELECT COUNT(*) as c FROM orders WHERE date(created_at)=?").get(today).c,
    pending_orders: db.prepare("SELECT COUNT(*) as c FROM orders WHERE payment_status='submitted'").get().c,
    verified_orders: db.prepare("SELECT COUNT(*) as c FROM orders WHERE payment_status='verified'").get().c,
    delivered_orders: db.prepare("SELECT COUNT(*) as c FROM orders WHERE delivery_status='delivered'").get().c,
    rejected_orders: db.prepare("SELECT COUNT(*) as c FROM orders WHERE payment_status='rejected'").get().c,
    total_revenue: db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM orders WHERE payment_status='verified'").get().s,
    today_revenue: db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM orders WHERE payment_status='verified' AND date(created_at)=?").get(today).s,
    total_books: db.prepare("SELECT COUNT(*) as c FROM books").get().c,
    published_books: db.prepare("SELECT COUNT(*) as c FROM books WHERE is_published=1").get().c,
    total_customers: db.prepare("SELECT COUNT(*) as c FROM customers").get().c,
  };

  // Sales by day (last 30 days)
  const salesByDay = db.prepare(`
    SELECT date(created_at) as date, SUM(amount) as revenue, COUNT(*) as orders
    FROM orders WHERE payment_status='verified'
    AND created_at >= date('now', '-30 days')
    GROUP BY date(created_at) ORDER BY date ASC
  `).all();

  // Top books
  const topBooks = db.prepare(`SELECT b.title, b.author, b.sales_count, b.price
    FROM books b ORDER BY b.sales_count DESC LIMIT 5`).all();

  // Orders by status
  const ordersByStatus = db.prepare(`SELECT order_status, COUNT(*) as count FROM orders GROUP BY order_status`).all();

  // Recent orders
  const recentOrders = db.prepare(`SELECT o.*, GROUP_CONCAT(oi.book_title, ', ') as books
    FROM orders o LEFT JOIN order_items oi ON oi.order_id=o.id
    GROUP BY o.id ORDER BY o.created_at DESC LIMIT 10`).all();

  // Unread notifications
  const notifications = db.prepare(`SELECT * FROM notifications ORDER BY created_at DESC LIMIT 20`).all();
  const unreadCount = db.prepare(`SELECT COUNT(*) as c FROM notifications WHERE is_read=0`).get().c;

  res.json({ stats, salesByDay, topBooks, ordersByStatus, recentOrders, notifications, unreadCount });
});

// GET /api/admin/notifications
router.get('/notifications', adminAuth, (req, res) => {
  const notifications = db.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 50').all();
  db.prepare('UPDATE notifications SET is_read=1 WHERE is_read=0').run();
  const unreadCount = db.prepare('SELECT COUNT(*) as c FROM notifications WHERE is_read=0').get().c;
  res.json({ notifications, unreadCount });
});

// GET /api/admin/settings
router.get('/settings', adminAuth, (req, res) => {
  res.json({ settings: getSettings() });
});

// PUT /api/admin/settings
router.put('/settings', adminAuth, (req, res) => {
  const allowed = [
    'site_name','site_tagline','footer_text','contact_email','whatsapp_number',
    'jazzcash_number','easypaisa_number','account_name','currency',
    'free_delivery_threshold','carousel_visible','accent_color',
    'download_expiry_hours','max_downloads'
  ];
  const updates = req.body;
  Object.keys(updates).forEach(key => {
    if (allowed.includes(key)) setSetting(key, updates[key]);
  });
  res.json({ success: true, settings: getSettings() });
});

// GET /api/admin/customers
router.get('/customers', adminAuth, (req, res) => {
  const customers = db.prepare(`SELECT c.*, COUNT(o.id) as order_count,
    COALESCE(SUM(CASE WHEN o.payment_status='verified' THEN o.amount ELSE 0 END),0) as total_spent
    FROM customers c LEFT JOIN orders o ON o.customer_email=c.email
    GROUP BY c.id ORDER BY c.created_at DESC`).all();
  res.json({ customers });
});

module.exports = router;
