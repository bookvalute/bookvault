const express = require('express');
const router = express.Router();
const path = require('path');
const { db } = require('../config/database');
const { adminAuth } = require('../middleware/auth');
const { generateDownloadToken, getSetting } = require('../utils/helpers');
const { sendDownloadLink, sendRejectionEmail } = require('../utils/email');
const { SCREENSHOTS_PATH } = require('../middleware/upload');

// GET /api/admin/orders
router.get('/', adminAuth, (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;
  let where = '';
  const params = [];
  if (status) { where = 'WHERE o.order_status = ?'; params.push(status); }

  const orders = db.prepare(`
    SELECT o.*, GROUP_CONCAT(oi.book_title, ', ') as books
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.id
    ${where} GROUP BY o.id
    ORDER BY o.created_at DESC LIMIT ? OFFSET ?
  `).all(...params, parseInt(limit), offset);

  const total = db.prepare(`SELECT COUNT(*) as c FROM orders ${where}`).get(...params);
  res.json({ orders, total: total.c, page: parseInt(page), limit: parseInt(limit) });
});

// GET /api/admin/orders/:id
router.get('/:id', adminAuth, (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  const items = db.prepare(`SELECT oi.*, b.cover_filename, b.pdf_filename
    FROM order_items oi LEFT JOIN books b ON b.id = oi.book_id
    WHERE oi.order_id = ?`).all(order.id);

  const downloads = db.prepare('SELECT * FROM downloads WHERE order_id = ?').all(order.id);

  res.json({
    order,
    items,
    downloads,
    screenshot_url: order.screenshot_filename ? `/api/admin/orders/${order.id}/screenshot` : null
  });
});

// GET /api/admin/orders/:id/screenshot — private screenshot view
router.get('/:id/screenshot', adminAuth, (req, res) => {
  const order = db.prepare('SELECT screenshot_filename FROM orders WHERE id = ?').get(req.params.id);
  if (!order?.screenshot_filename) return res.status(404).json({ error: 'No screenshot' });

  const filePath = path.join(path.resolve(SCREENSHOTS_PATH), order.screenshot_filename);
  res.sendFile(filePath, err => {
    if (err) res.status(404).json({ error: 'File not found' });
  });
});

// POST /api/admin/orders/:id/verify — verify payment
router.post('/:id/verify', adminAuth, async (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.payment_status === 'verified') return res.status(400).json({ error: 'Already verified' });

  db.prepare(`UPDATE orders SET payment_status='verified', order_status='processing',
    verified_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(order.id);

  db.prepare(`INSERT INTO notifications (type, title, message, data) VALUES (?, ?, ?, ?)`)
    .run('payment_verified', `Payment verified: ${order.order_number}`, `PKR ${order.amount}`, JSON.stringify({ order_id: order.id }));

  res.json({ success: true, message: 'Payment verified. You can now deliver the PDF.' });
});

// POST /api/admin/orders/:id/reject — reject payment
router.post('/:id/reject', adminAuth, async (req, res) => {
  const { reason } = req.body;
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  db.prepare(`UPDATE orders SET payment_status='rejected', order_status='payment_rejected',
    admin_note=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(reason || null, order.id);

  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
  const book = items[0] ? db.prepare('SELECT * FROM books WHERE id = ?').get(items[0].book_id) : { title: 'Book', author: '' };

  sendRejectionEmail(order, book, reason).catch(e => console.error('Rejection email failed:', e));

  res.json({ success: true, message: 'Order rejected and customer notified.' });
});

// POST /api/admin/orders/:id/deliver — generate download link and email
router.post('/:id/deliver', adminAuth, async (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.payment_status !== 'verified') return res.status(400).json({ error: 'Payment must be verified first' });

  const items = db.prepare(`SELECT oi.*, b.pdf_filename, b.title as book_title, b.author as book_author
    FROM order_items oi JOIN books b ON b.id=oi.book_id WHERE oi.order_id=?`).all(order.id);

  if (!items.length) return res.status(400).json({ error: 'No items in order' });

  const expiryHours = parseInt(getSetting('download_expiry_hours') || process.env.DOWNLOAD_LINK_EXPIRY_HOURS || 72);
  const maxDownloads = parseInt(getSetting('max_downloads') || process.env.MAX_DOWNLOAD_COUNT || 5);

  const tokens = [];

  db.transaction(() => {
    // Deactivate old tokens
    db.prepare('UPDATE downloads SET is_active=0 WHERE order_id=?').run(order.id);

    items.forEach(item => {
      const token = generateDownloadToken();
      const expiresAt = new Date(Date.now() + expiryHours * 60 * 60 * 1000).toISOString();
      db.prepare(`INSERT INTO downloads (token, order_id, order_item_id, book_id, customer_email, max_downloads, expires_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)`).run(token, order.id, item.id, item.book_id, order.customer_email, maxDownloads, expiresAt);
      tokens.push({ token, book_title: item.book_title });

      db.prepare('UPDATE books SET sales_count = sales_count + 1 WHERE id = ?').run(item.book_id);
    });

    db.prepare(`UPDATE orders SET delivery_status='delivered', order_status='delivered',
      delivered_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(order.id);

    db.prepare(`UPDATE customers SET order_count=order_count+1, total_spent=total_spent+? WHERE email=?`)
      .run(order.amount, order.customer_email);
  })();

  // Send email with first book (for single purchases)
  const firstItem = items[0];
  try {
    await sendDownloadLink(order, { title: firstItem.book_title, author: firstItem.book_author }, tokens[0].token);
  } catch (e) {
    console.error('Delivery email failed:', e);
  }

  res.json({ success: true, message: 'PDF delivered! Customer has been emailed.', tokens });
});

// POST /api/admin/orders/:id/cancel
router.post('/:id/cancel', adminAuth, (req, res) => {
  db.prepare(`UPDATE orders SET order_status='cancelled', updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(req.params.id);
  db.prepare('UPDATE downloads SET is_active=0 WHERE order_id=?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
