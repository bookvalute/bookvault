const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { db } = require('../config/database');
const { PDF_PATH } = require('../middleware/upload');

// GET /api/download/:token
router.get('/:token', (req, res) => {
  const { token } = req.params;
  if (!token || token.length < 32) return res.status(400).json({ error: 'Invalid token' });

  const download = db.prepare(`SELECT d.*, b.pdf_filename, b.title as book_title, b.author as book_author,
    o.payment_status, o.customer_email
    FROM downloads d
    JOIN books b ON b.id = d.book_id
    JOIN orders o ON o.id = d.order_id
    WHERE d.token = ?`).get(token);

  if (!download) return res.status(404).json({ error: 'Download link not found' });
  if (!download.is_active) return res.status(410).json({ error: 'This download link has been deactivated' });
  if (new Date(download.expires_at) < new Date()) return res.status(410).json({ error: 'This download link has expired. Please contact support.' });
  if (download.download_count >= download.max_downloads) return res.status(429).json({ error: 'Download limit reached. Please contact support.' });
  if (download.payment_status !== 'verified') return res.status(403).json({ error: 'Payment not verified yet' });
  if (!download.pdf_filename) return res.status(404).json({ error: 'PDF file not found' });

  const filePath = path.join(path.resolve(PDF_PATH), download.pdf_filename);
  if (!fs.existsSync(filePath)) {
    console.error('PDF file missing:', filePath);
    return res.status(404).json({ error: 'PDF file not found on server. Please contact support.' });
  }

  // Update download count
  db.prepare(`UPDATE downloads SET download_count = download_count + 1,
    last_downloaded_at = CURRENT_TIMESTAMP WHERE id = ?`).run(download.id);

  // Sanitize filename for Content-Disposition
  const safeTitle = download.book_title.replace(/[^a-zA-Z0-9\s-_]/g, '').trim() || 'book';

  res.setHeader('Content-Disposition', `attachment; filename="${safeTitle}.pdf"`);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');

  const stream = fs.createReadStream(filePath);
  stream.on('error', err => {
    console.error('Stream error:', err);
    if (!res.headersSent) res.status(500).json({ error: 'Download failed' });
  });
  stream.pipe(res);
});

// GET /api/download/info/:token — check token status without downloading
router.get('/info/:token', (req, res) => {
  const download = db.prepare(`SELECT d.expires_at, d.download_count, d.max_downloads, d.is_active,
    b.title, b.author, o.payment_status
    FROM downloads d JOIN books b ON b.id=d.book_id JOIN orders o ON o.id=d.order_id
    WHERE d.token = ?`).get(req.params.token);

  if (!download) return res.status(404).json({ error: 'Link not found' });

  res.json({
    book_title: download.title,
    book_author: download.author,
    payment_status: download.payment_status,
    is_active: download.is_active,
    is_expired: new Date(download.expires_at) < new Date(),
    downloads_used: download.download_count,
    downloads_remaining: Math.max(0, download.max_downloads - download.download_count),
    expires_at: download.expires_at
  });
});

module.exports = router;
