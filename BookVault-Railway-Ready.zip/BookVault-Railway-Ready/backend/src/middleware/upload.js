const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const STORAGE_PATH = process.env.STORAGE_PATH || './storage';
const PDF_PATH = path.join(STORAGE_PATH, 'books/private');
const COVERS_PATH = path.join(STORAGE_PATH, 'covers');
const SCREENSHOTS_PATH = path.join(STORAGE_PATH, 'screenshots');

[PDF_PATH, COVERS_PATH, SCREENSHOTS_PATH].forEach(p => {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
});

// Block directory listing
const blockAccess = (dir) => {
  const htaccess = path.join(dir, '.htaccess');
  if (!fs.existsSync(htaccess)) {
    fs.writeFileSync(htaccess, 'Deny from all\n');
  }
};
blockAccess(PDF_PATH);
blockAccess(SCREENSHOTS_PATH);

function makeStorage(destPath) {
  return multer.diskStorage({
    destination: (req, file, cb) => cb(null, destPath),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${uuidv4()}${ext}`);
    }
  });
}

const imageFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png', '.webp'];
  const ext = path.extname(file.originalname).toLowerCase();
  if (!allowed.includes(ext)) return cb(new Error('Only JPG, PNG, WEBP allowed'));
  cb(null, true);
};

const pdfFilter = (req, file, cb) => {
  if (path.extname(file.originalname).toLowerCase() !== '.pdf') {
    return cb(new Error('Only PDF files allowed'));
  }
  if (file.mimetype !== 'application/pdf') {
    return cb(new Error('Invalid PDF mimetype'));
  }
  cb(null, true);
};

const uploadCover = multer({
  storage: makeStorage(COVERS_PATH),
  fileFilter: imageFilter,
  limits: { fileSize: parseInt(process.env.MAX_IMAGE_SIZE) || 5 * 1024 * 1024 }
});

const uploadPDF = multer({
  storage: makeStorage(PDF_PATH),
  fileFilter: pdfFilter,
  limits: { fileSize: parseInt(process.env.MAX_PDF_SIZE) || 50 * 1024 * 1024 }
});

const uploadScreenshot = multer({
  storage: makeStorage(SCREENSHOTS_PATH),
  fileFilter: imageFilter,
  limits: { fileSize: parseInt(process.env.MAX_IMAGE_SIZE) || 5 * 1024 * 1024 }
});

module.exports = { uploadCover, uploadPDF, uploadScreenshot, PDF_PATH, COVERS_PATH, SCREENSHOTS_PATH };
