const jwt = require('jsonwebtoken');
const { db } = require('../config/database');

function adminAuth(req, res, next) {
  try {
    const token = req.cookies?.admin_token || req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Unauthorized' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

    const admin = db.prepare('SELECT id, email, name FROM admins WHERE id = ?').get(decoded.id);
    if (!admin) return res.status(401).json({ error: 'Admin not found' });

    req.admin = admin;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

module.exports = { adminAuth };
