const nodemailer = require('nodemailer');

let transporter;

function getTransporter() {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT) || 587,
      secure: process.env.EMAIL_SECURE === 'true',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
      }
    });
  }
  return transporter;
}

async function sendOrderConfirmation(order, book) {
  const t = getTransporter();
  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body{font-family:'Segoe UI',sans-serif;background:#06070f;color:#ede8da;margin:0;padding:0;}
  .wrap{max-width:600px;margin:0 auto;padding:40px 20px;}
  .logo{font-family:Georgia,serif;font-size:28px;color:#c9913a;text-align:center;margin-bottom:30px;}
  .card{background:#13152a;border:1px solid #1e2240;border-radius:12px;padding:30px;margin-bottom:20px;}
  .label{font-size:11px;color:#7a7d9a;letter-spacing:2px;text-transform:uppercase;margin-bottom:6px;}
  .value{font-size:16px;color:#ede8da;margin-bottom:16px;}
  .price{font-family:Georgia,serif;font-size:28px;color:#c9913a;}
  .divider{border:none;border-top:1px solid #1e2240;margin:20px 0;}
  .footer{text-align:center;color:#7a7d9a;font-size:12px;margin-top:30px;}
</style></head>
<body><div class="wrap">
  <div class="logo">BookVault ✦</div>
  <div class="card">
    <h2 style="color:#c9913a;margin-top:0;">Order Confirmed! 📚</h2>
    <p>Hi <strong>${order.customer_name}</strong>, your order has been received.</p>
    <hr class="divider">
    <div class="label">Order Number</div><div class="value">${order.order_number}</div>
    <div class="label">Book</div><div class="value">${book.title} by ${book.author}</div>
    <div class="label">Amount</div><div class="price">PKR ${Number(order.amount).toLocaleString()}</div>
    <hr class="divider">
    <p style="color:#7a7d9a;font-size:14px;">
      ⏳ Your payment is being verified. Once verified, you will receive a secure download link within a few hours.
    </p>
  </div>
  <div class="footer">© 2024 BookVault. All rights reserved.</div>
</div></body></html>`;

  await t.sendMail({
    from: `"${process.env.EMAIL_FROM_NAME || 'BookVault'}" <${process.env.EMAIL_FROM}>`,
    to: order.customer_email,
    subject: `Order Received — ${order.order_number} 📚`,
    html
  });
}

async function sendDownloadLink(order, book, downloadToken) {
  const t = getTransporter();
  const downloadUrl = `${process.env.FRONTEND_URL}/api/download/${downloadToken}`;
  const expiryHours = process.env.DOWNLOAD_LINK_EXPIRY_HOURS || 72;

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body{font-family:'Segoe UI',sans-serif;background:#06070f;color:#ede8da;margin:0;padding:0;}
  .wrap{max-width:600px;margin:0 auto;padding:40px 20px;}
  .logo{font-family:Georgia,serif;font-size:28px;color:#c9913a;text-align:center;margin-bottom:30px;}
  .card{background:#13152a;border:1px solid #1e2240;border-radius:12px;padding:30px;margin-bottom:20px;}
  .label{font-size:11px;color:#7a7d9a;letter-spacing:2px;text-transform:uppercase;margin-bottom:6px;}
  .value{font-size:16px;color:#ede8da;margin-bottom:16px;}
  .price{font-family:Georgia,serif;font-size:28px;color:#c9913a;}
  .btn{display:inline-block;background:linear-gradient(135deg,#c9913a,#8a5a10);color:#06070f;
    padding:16px 40px;border-radius:10px;text-decoration:none;font-weight:700;font-size:16px;
    margin:20px auto;text-align:center;}
  .divider{border:none;border-top:1px solid #1e2240;margin:20px 0;}
  .warning{background:rgba(201,145,58,.1);border:1px solid #c9913a;border-radius:8px;
    padding:14px;font-size:13px;color:#c9913a;margin:16px 0;}
  .footer{text-align:center;color:#7a7d9a;font-size:12px;margin-top:30px;}
</style></head>
<body><div class="wrap">
  <div class="logo">BookVault ✦</div>
  <div class="card">
    <h2 style="color:#3dd68c;margin-top:0;">✅ Payment Verified — Your Book is Ready!</h2>
    <p>Hi <strong>${order.customer_name}</strong>, great news!</p>
    <hr class="divider">
    <div class="label">Order</div><div class="value">${order.order_number}</div>
    <div class="label">Book</div><div class="value" style="font-family:Georgia,serif;font-size:20px;">${book.title}</div>
    <div class="label">Author</div><div class="value">${book.author}</div>
    <div class="label">Amount Paid</div><div class="price">PKR ${Number(order.amount).toLocaleString()}</div>
    <hr class="divider">
    <div style="text-align:center;">
      <a href="${downloadUrl}" class="btn">📥 Download Your PDF</a>
    </div>
    <div class="warning">
      ⚠️ This download link expires in <strong>${expiryHours} hours</strong> and can be used up to <strong>${process.env.MAX_DOWNLOAD_COUNT || 5} times</strong>. Please download and save your book immediately.
    </div>
    <p style="color:#7a7d9a;font-size:13px;">If the button doesn't work, copy this link:<br>
    <code style="color:#c9913a;word-break:break-all;">${downloadUrl}</code></p>
  </div>
  <div class="footer">© 2024 BookVault. All rights reserved.</div>
</div></body></html>`;

  await t.sendMail({
    from: `"${process.env.EMAIL_FROM_NAME || 'BookVault'}" <${process.env.EMAIL_FROM}>`,
    to: order.customer_email,
    subject: `Your Book is Ready — Download Now! 📥`,
    html
  });
}

async function sendAdminNotification(order, book) {
  const t = getTransporter();
  const adminEmail = process.env.ADMIN_EMAIL_NOTIFY;
  if (!adminEmail) return;

  const html = `
<div style="font-family:sans-serif;max-width:500px;margin:0 auto;padding:30px;background:#13152a;color:#ede8da;border-radius:12px;">
  <h2 style="color:#c9913a;">🔔 New Order Received</h2>
  <table style="width:100%;border-collapse:collapse;">
    <tr><td style="padding:8px 0;color:#7a7d9a;">Order:</td><td style="color:#c9913a;font-weight:bold;">${order.order_number}</td></tr>
    <tr><td style="padding:8px 0;color:#7a7d9a;">Customer:</td><td>${order.customer_name}</td></tr>
    <tr><td style="padding:8px 0;color:#7a7d9a;">Email:</td><td>${order.customer_email}</td></tr>
    <tr><td style="padding:8px 0;color:#7a7d9a;">Phone:</td><td>${order.customer_phone}</td></tr>
    <tr><td style="padding:8px 0;color:#7a7d9a;">Book:</td><td>${book.title}</td></tr>
    <tr><td style="padding:8px 0;color:#7a7d9a;">Amount:</td><td style="color:#c9913a;font-family:Georgia,serif;font-size:18px;">PKR ${Number(order.amount).toLocaleString()}</td></tr>
    <tr><td style="padding:8px 0;color:#7a7d9a;">Payment:</td><td>${order.payment_method.toUpperCase()}</td></tr>
    <tr><td style="padding:8px 0;color:#7a7d9a;">Transaction ID:</td><td>${order.transaction_id || 'N/A'}</td></tr>
  </table>
  <div style="margin-top:20px;text-align:center;">
    <a href="${process.env.FRONTEND_URL}/admin/orders/${order.id}"
      style="display:inline-block;background:#c9913a;color:#06070f;padding:12px 30px;
      border-radius:8px;text-decoration:none;font-weight:700;">VIEW ORDER</a>
  </div>
</div>`;

  await t.sendMail({
    from: `"BookVault System" <${process.env.EMAIL_FROM}>`,
    to: adminEmail,
    subject: `🔔 New Order: ${order.order_number} — PKR ${Number(order.amount).toLocaleString()}`,
    html
  });
}

async function sendRejectionEmail(order, book, reason) {
  const t = getTransporter();
  const html = `
<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
  body{font-family:'Segoe UI',sans-serif;background:#06070f;color:#ede8da;}
  .wrap{max-width:600px;margin:0 auto;padding:40px 20px;}
  .card{background:#13152a;border:1px solid #1e2240;border-radius:12px;padding:30px;}
  .logo{font-family:Georgia,serif;font-size:28px;color:#c9913a;text-align:center;margin-bottom:30px;}
</style></head>
<body><div class="wrap">
  <div class="logo">BookVault ✦</div>
  <div class="card">
    <h2 style="color:#e04545;">❌ Payment Issue — Order ${order.order_number}</h2>
    <p>Hi <strong>${order.customer_name}</strong>,</p>
    <p>Unfortunately, we could not verify your payment for <strong>${book.title}</strong>.</p>
    ${reason ? `<p><strong>Reason:</strong> ${reason}</p>` : ''}
    <p>Please contact us on WhatsApp or re-place your order. We apologize for the inconvenience.</p>
    <p style="color:#7a7d9a;font-size:13px;margin-top:20px;">If you believe this is a mistake, please contact us with your transaction ID.</p>
  </div>
</div></body></html>`;

  await t.sendMail({
    from: `"${process.env.EMAIL_FROM_NAME || 'BookVault'}" <${process.env.EMAIL_FROM}>`,
    to: order.customer_email,
    subject: `Payment Issue — Order ${order.order_number}`,
    html
  });
}

module.exports = { sendOrderConfirmation, sendDownloadLink, sendAdminNotification, sendRejectionEmail };
