const crypto = require('crypto');
const { db } = require('../config/database');

function generateOrderNumber() {
  const now = new Date();
  const date = now.toISOString().slice(0, 10).replace(/-/g, '');
  const count = db.prepare('SELECT COUNT(*) as c FROM orders WHERE date(created_at) = date("now")').get();
  const seq = String((count.c || 0) + 1).padStart(4, '0');
  return `BV-${date}-${seq}`;
}

function generateDownloadToken() {
  return crypto.randomBytes(48).toString('hex');
}

function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

function setSetting(key, value) {
  db.prepare('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)')
    .run(key, value);
}

function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}

function formatPKR(amount) {
  return `PKR ${Number(amount).toLocaleString('en-PK')}`;
}

module.exports = { generateOrderNumber, generateDownloadToken, getSetting, setSetting, getSettings, formatPKR };
